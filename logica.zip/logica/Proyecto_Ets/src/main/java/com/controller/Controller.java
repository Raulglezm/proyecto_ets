/**package com.controller;

public class Controller {

    
//PARTE DE LA TIENDA

public void crearTienda(){

}

public void crearAlmacen(){

}

public void crearProducto(){

}

}
**/