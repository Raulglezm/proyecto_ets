package com.mycompany.proyecto_ets;

public class Cliente {

    int id;
    String nombre;
    String apellido;

    /**
     * Constructor con tres parametrod de Cliente
     * @param id del cliente
     * @param nombre del cliente
     * @param apellido del cliente
     */
    public Cliente(int id, String nombre, String apellido) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
    }

}
